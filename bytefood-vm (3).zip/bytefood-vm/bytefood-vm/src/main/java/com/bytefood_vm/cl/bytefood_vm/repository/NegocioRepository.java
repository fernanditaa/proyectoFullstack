package com.bytefood_vm.cl.bytefood_vm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bytefood_vm.cl.bytefood_vm.model.Negocio;

@Repository
public interface NegocioRepository extends JpaRepository<Negocio, Long> {


    List<Negocio> findByNombreNegocio(String nombreNegocio);

    Negocio findByDireccion(String direccion);

    List<Negocio> findByNombreNegocioAndDireccion(String nombreNegocio, String direccion);

    Negocio findById(Integer id);

}
