package com.bytefood_vm.cl.bytefood_vm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bytefood_vm.cl.bytefood_vm.model.Pedido;
import com.bytefood_vm.cl.bytefood_vm.repository.PedidoRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    public List<Pedido> findAll() {
        return pedidoRepository.findAll();
    }
    public Pedido findById(Long id) {
        return pedidoRepository.getById(id);
    }
    public Pedido save(Pedido pedido) {
        return pedidoRepository.save(pedido);
    }
    public void deleteById(Long id) {
        pedidoRepository.deleteById(id);
    }
    public Pedido patchPedido(Long id, Pedido parcialPedido) {
        Optional<Pedido> pedidoOptional = pedidoRepository.findById(id);
        if (pedidoOptional.isPresent()) {
            Pedido pedido = pedidoOptional.get();
            if (parcialPedido.getDireccionEntrega() != null) {
                pedido.setDireccionEntrega(parcialPedido.getDireccionEntrega());
            }
            if (parcialPedido.getEstado() != null) {
                pedido.setEstado(parcialPedido.getEstado());
            }
            return pedidoRepository.save(pedido);
        } else {
            return null;
        }
    }

}
