package com.bytefood_vm.cl.bytefood_vm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bytefood_vm.cl.bytefood_vm.model.Producto;
import com.bytefood_vm.cl.bytefood_vm.repository.ProductoRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> findAll() {
        return productoRepository.findAll();
    }

    public Producto findById(long id) {
        return productoRepository.getById(id);
    }
    public Producto save(Producto producto) {
        return productoRepository.save(producto);
    }
    public void deleteById(long id) {
        productoRepository.deleteById(id);
    }
    public Producto patchProducto(Long id, Producto parcialproducto) {
        Producto producto = productoRepository.findById(id).orElse(null);
        if (producto != null) {
            if (parcialproducto.getNombre() != null) {
                producto.setNombre(parcialproducto.getNombre());
            }
            if (parcialproducto.getDescripcion() != null) {
                producto.setDescripcion(parcialproducto.getDescripcion());
            }
            if (parcialproducto.getPrecio() != null) {
                producto.setPrecio(parcialproducto.getPrecio());
            }
            if (parcialproducto.getStock() != null) {
                producto.setStock(parcialproducto.getStock());
            }
            return productoRepository.save(producto);
        } else {
            return null;
        }
    }

}
