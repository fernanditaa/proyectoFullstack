package com.bytefood_vm.cl.bytefood_vm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bytefood_vm.cl.bytefood_vm.model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    @Query("""
            SELECT u FROM Producto u
        """)
    List<Producto> findAll();
    
    List<Producto> findByNombre(String nombre);

    Producto findByDescripcion(String descripcion);

    Producto findById(Integer id);
    List<Producto> findByNombreAndDescripcion(String nombre, String descripcion);
}
