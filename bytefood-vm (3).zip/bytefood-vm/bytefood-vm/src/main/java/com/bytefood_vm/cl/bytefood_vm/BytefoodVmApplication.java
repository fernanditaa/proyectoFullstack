package com.bytefood_vm.cl.bytefood_vm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BytefoodVmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BytefoodVmApplication.class, args);
	}

}
