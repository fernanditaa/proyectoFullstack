package com.bytefood_vm.cl.bytefood_vm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bytefood_vm.cl.bytefood_vm.model.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    @Query("""
            SELECT u.id, u.nombre, u.apellidos, u.correo, u.telefono FROM Usuario u
        """)
    List<Usuario> findByApellidos(String apellidos);

    Usuario findByCorreo(String correo);

    List<Usuario> findByNombreAndApellidos(String nombre, String apellidos);
    
    Usuario findById(Integer id);
}
