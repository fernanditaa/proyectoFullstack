package com.bytefood_vm.cl.bytefood_vm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bytefood_vm.cl.bytefood_vm.model.Negocio;
import com.bytefood_vm.cl.bytefood_vm.repository.NegocioRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class NegocioService {

    @Autowired
    private NegocioRepository negocioRepository;
    
    public List<Negocio> findAll() {
        return negocioRepository.findAll();
    }
    public Negocio findById(long id) {
        return negocioRepository.getById(id);
    }
    public Negocio save(Negocio negocio) {
        return negocioRepository.save(negocio);
    }
    public void deleteById(long id) {
        negocioRepository.deleteById(id);
    }
    public Negocio patchNegocio(Long id, Negocio parcialnegocio) {
        Optional<Negocio> negocioOptional = negocioRepository.findById(id);
        if (negocioOptional.isPresent ()) {
            Negocio negocio = negocioOptional.get();
            if (parcialnegocio.getNombreNegocio() != null) {
                negocio.setNombreNegocio(parcialnegocio.getNombreNegocio());
            }
            if (parcialnegocio.getDireccion() != null) {
                negocio.setDireccion(parcialnegocio.getDireccion());
            }
            if (parcialnegocio.getTelefono() != null) {
                negocio.setTelefono(parcialnegocio.getTelefono());
            }
            return negocioRepository.save(negocio);
        } else {
            return null;
        }
    }
}
