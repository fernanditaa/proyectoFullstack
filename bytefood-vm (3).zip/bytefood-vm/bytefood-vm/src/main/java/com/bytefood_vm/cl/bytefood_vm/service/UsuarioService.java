package com.bytefood_vm.cl.bytefood_vm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bytefood_vm.cl.bytefood_vm.model.Usuario;
import com.bytefood_vm.cl.bytefood_vm.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<Usuario> findAll() {
        return usuarioRepository.findAll();
    }

    public Usuario findById(long id) {
        return usuarioRepository.getById(id);
    }

    public Usuario save(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }
    public void deleteById(long id) {
        usuarioRepository.deleteById(id);
    }
    public Usuario patchUsuario(Long id, Usuario parcialusuario) {
        Optional<Usuario> usuarioOptional = usuarioRepository.findById(id);
        if (usuarioOptional.isPresent()) {
            Usuario usuario = usuarioOptional.get();
            if (parcialusuario.getNombre() != null) {
                usuario.setNombre(parcialusuario.getNombre());
            }
            if (parcialusuario.getApellidos() != null) {
                usuario.setApellidos(parcialusuario.getApellidos());
            }
            if (parcialusuario.getCorreo() != null) {
                usuario.setCorreo(parcialusuario.getCorreo());
            }
            if (parcialusuario.getTelefono() != null) {
                usuario.setTelefono(parcialusuario.getTelefono());
            }
            if (parcialusuario.getPassword() != null) {
                usuario.setPassword(parcialusuario.getPassword());
            }
            return usuarioRepository.save(usuario);
        } else {
            return null;
        }
    }
}
