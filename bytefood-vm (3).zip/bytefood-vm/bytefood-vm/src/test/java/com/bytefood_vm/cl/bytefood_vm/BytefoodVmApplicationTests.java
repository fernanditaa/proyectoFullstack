package com.bytefood_vm.cl.bytefood_vm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BytefoodVmApplicationTests {

	@Test
	void contextLoads() {
	}

}
